/**
 * react-native-dash-ota — public API.
 */
export { DashOtaProvider } from './DashOtaProvider.js';
export type { DashOtaProviderProps } from './DashOtaProvider.js';
export { useOtaUpdate } from './useOtaUpdate.js';
export { consoleLogger, STORAGE_KEYS } from './config.js';
export type { OtaConfig, OtaStorage } from './config.js';
export { noopTransportSecurity, noopIntegrityAttestor } from './verifiers.js';
export type { TransportSecurity, IntegrityAttestor } from './verifiers.js';
export type { Channel, Platform, OtaStatus, BundleMeta, OtaNativeState, NativeVersionPolicy, SignedManifest, CheckResponse, AvailableUpdate, OtaLogger, OtaUpdateState, } from './types.js';
//# sourceMappingURL=index.d.ts.map