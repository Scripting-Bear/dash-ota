/**
 * Host-injected configuration. The package is storage- and transport-agnostic: the host app
 * provides a key/value storage adapter (for the install id), an optional logger, and optional
 * pinning/attestation plug-ins. Server URL / channel / runtimeVersion / public keys come from
 * the **native** side (embedded per build flavour), so they can't be tampered from JS. The
 * per-request signing key is a non-exportable hardware key held in the Keystore / Enclave.
 */
import type { IntegrityAttestor, TransportSecurity } from './verifiers.js';
import type { OtaLogger, OtaStatus } from './types.js';
/** Minimal async key/value storage (e.g. AsyncStorage or secure storage). */
export interface OtaStorage {
    getItem: (key: string) => Promise<string | null>;
    setItem: (key: string, value: string) => Promise<void>;
}
/** Configuration passed to {@link DashOtaProvider}. */
export interface OtaConfig {
    /** persistence for the install id (the signing key lives in the hardware Keystore / Enclave). */
    storage: OtaStorage;
    /** app marketing version (for `targetAppVersions` matching). */
    appVersion: string;
    /**
     * Master switch (default `true`). When `false`, the provider mounts but performs **no** OTA
     * activity — no enroll, check, download, or apply — and reports status `disabled`. Use it to
     * withhold OTA from a runtime you don't trust (e.g. a jailbroken / rooted device) so it keeps
     * running only the store-shipped binary.
     */
    enabled?: boolean;
    /** check for an update automatically on launch (default true). */
    autoCheckOnLaunch?: boolean;
    /** automatically stage + schedule an apply when an update is found (default true). */
    autoStage?: boolean;
    /**
     * Auto-promote the running bundle to last-known-good this many ms after a successful mount,
     * so hosts don't have to wire `markHealthy()` by hand. Omit (default) to keep it **manual** —
     * the safest choice, since calling `markHealthy()` only after your real first screen renders
     * gives the crash-loop breaker its full protection. A value like `4000` is a reasonable
     * plug-and-play default for simple apps.
     */
    autoMarkHealthyMs?: number;
    /** re-run a check when the app returns to the foreground (default false). */
    checkOnAppForeground?: boolean;
    /** observability hook fired on every lifecycle status transition. */
    onStatusChange?: (status: OtaStatus) => void;
    /** override the native-embedded server URL (POC/testing only). */
    serverUrlOverride?: string;
    /** returns the app's authenticated session token, attached to enroll (ties the device key to a user). */
    getEnrollToken?: () => Promise<string | undefined>;
    logger?: OtaLogger;
    transport?: TransportSecurity;
    attestor?: IntegrityAttestor;
}
/** Storage keys used internally. */
export declare const STORAGE_KEYS: {
    readonly installId: "dash-ota.installId";
    /**
     * Marker proving this install already enrolled its current device key, so we don't re-POST
     * `/enroll` (and re-attest, burning attestation quota) on every cold start. Value =
     * `sha256(installId + ':' + devicePublicKeyB64)`, so a key rotation or reinstall re-enrolls.
     */
    readonly enrolled: "dash-ota.enrolled";
};
/** Default console logger. */
export declare const consoleLogger: OtaLogger;
//# sourceMappingURL=config.d.ts.map