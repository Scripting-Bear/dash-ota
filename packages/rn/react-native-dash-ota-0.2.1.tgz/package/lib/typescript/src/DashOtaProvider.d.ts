/**
 * DashOtaProvider — orchestrates the OTA lifecycle and exposes it via {@link useOtaUpdate}.
 * On launch it reads the current bundle, enrolls (once), and (by default) checks → downloads
 * → natively verifies/stages → schedules an apply on next cold start. Everything fails closed:
 * any error leaves the last-known-good/embedded bundle running.
 */
import React from 'react';
import { type OtaConfig } from './config.js';
import type { OtaUpdateState } from './types.js';
/** Provider props. */
export interface DashOtaProviderProps {
    config: OtaConfig;
    children: React.ReactNode;
}
/**
 * Wrap your app root to enable OTA. On launch it reads the current bundle, enrolls the hardware
 * device key (once), and — by default — checks → downloads → natively verifies/stages → schedules
 * an apply on next cold start. Everything fails closed: any error leaves the last-known-good /
 * embedded bundle running. State + actions are exposed via {@link useOtaUpdate}.
 *
 * @param props `config` ({@link OtaConfig}) + your app's `children`.
 *
 * @example
 * ```tsx
 * import { DashOtaProvider } from 'react-native-dash-ota';
 *
 * export default function Root() {
 *   return (
 *     <DashOtaProvider
 *       config={{
 *         appVersion: '1.4.0',
 *         storage,                                     // AsyncStorage / MMKV / secure-storage adapter
 *         getEnrollToken: () => auth.getSessionToken(), // ties the device key to a real user
 *         checkOnAppForeground: true,
 *       }}
 *     >
 *       <App />
 *     </DashOtaProvider>
 *   );
 * }
 * ```
 */
export declare function DashOtaProvider({ config, children }: DashOtaProviderProps): React.ReactElement;
/** Internal: read the OTA context (throws if used outside the provider). */
export declare function useOtaContext(): OtaUpdateState;
//# sourceMappingURL=DashOtaProvider.d.ts.map