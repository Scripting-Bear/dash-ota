/**
 * Canonical JSON — byte-identical to `@dash-ota/shared`'s `canonicalize` (and therefore to
 * what the CLI signed). Pure JS (no Node APIs), safe in Hermes. JS produces the canonical
 * manifest bytes; **native** verifies the Ed25519 signature over those exact bytes against the
 * embedded public key — so the integrity guarantee stays in native, while we avoid
 * reimplementing canonicalization in Kotlin/Swift.
 */
/** Serialize a value to its canonical JSON string (sorted keys, compact). */
export declare function canonicalize(value: unknown): string;
//# sourceMappingURL=canonical.d.ts.map