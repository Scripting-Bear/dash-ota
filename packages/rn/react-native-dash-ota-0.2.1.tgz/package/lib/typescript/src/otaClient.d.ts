/**
 * The OTA HTTP client: enroll, check, and confirm. Small JSON calls only — the heavy,
 * trust-critical bundle download + verify + decrypt is done natively via
 * {@link downloadAndStage}. Each request is signed **natively** with the device's
 * non-exportable hardware key (ECDSA-P256; no crypto in JS); the canonical signing string
 * matches the backend exactly.
 */
import { type OtaConfig } from './config.js';
import type { CheckResponse, OtaLogger } from './types.js';
/**
 * A request nonce, preferring the native CSPRNG ({@link DashOta.generateNonce}) and falling back to
 * a JS construction only if the native method is unavailable (e.g. an older native binary). The
 * native path is the real anti-replay guarantee; the fallback keeps enroll/check working rather
 * than hard-failing on a version skew.
 * @internal exported for tests
 */
export declare function makeNonce(): string;
/**
 * Build the canonical request-signing string — must match `@dash-ota/shared`'s `requestSigningString`.
 * @internal exported for the CLI↔native round-trip guard test
 */
export declare function signingString(method: string, path: string, installId: string, nonce: string, timestamp: string, bodySha256: string): string;
/** The resolved client context for a session. */
export interface OtaClientContext {
    serverUrl: string;
    channel: string;
    runtimeVersion: string;
    buildNumber: number;
    installId: string;
    fetchImpl: typeof fetch;
    logger: OtaLogger;
    /** Force a re-enroll (clears the once-marker): key rotation, or the server forgot this install. */
    reenroll: () => Promise<void>;
}
/**
 * Build a signed-request client context, enrolling the device's hardware public key on first use
 * (or on key rotation). Enrollment is idempotent and skipped when already done — see
 * {@link enrollIfNeeded} — so cold starts don't re-attest.
 */
export declare function createClientContext(config: OtaConfig, logger: OtaLogger): Promise<OtaClientContext>;
/** Ask the backend for an eligible update for this device. */
export declare function checkForUpdate(ctx: OtaClientContext, currentBundleVersion: number, appVersion: string): Promise<CheckResponse>;
/** Report an apply result (drives adoption + server-side auto-pause). */
export declare function confirm(ctx: OtaClientContext, bundleId: string, status: 'applied' | 'healthy' | 'failed' | 'rolled_back', serverNonce: string, reason?: string): Promise<void>;
/** The URL the native side downloads ciphertext from (no S3 URL on the JS side). */
export declare function downloadUrl(ctx: OtaClientContext): string;
//# sourceMappingURL=otaClient.d.ts.map